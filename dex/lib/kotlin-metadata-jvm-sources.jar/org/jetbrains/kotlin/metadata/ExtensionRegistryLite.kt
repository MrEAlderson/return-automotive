/*
 * Copyright 2010-2026 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.metadata

import org.jetbrains.kotlin.protobuf.ExtensionRegistryLite

fun ExtensionRegistryLite(register: ExtensionRegistryLite.() -> Unit): ExtensionRegistryLite {
    val registry = ExtensionRegistryLite.newInstance()
    registry.register()
    return registry.unmodifiable
}
